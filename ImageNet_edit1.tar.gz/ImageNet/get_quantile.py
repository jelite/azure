import sys

def main():
    filename = sys.argv[1]
    
    file = open(filename, 'r')
    lines = file.readlines()
    
    records = []
    for line in lines:
        line = line.strip()
        records.append(float(line))
    records.sort()

    print(sum(records[25:75]) / 50)
    
    file.close()
    
    return 0


if __name__ == '__main__':
    main()
