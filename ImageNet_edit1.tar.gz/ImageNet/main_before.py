import argparse
import os
import time

import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data

from models import *
from data_loader import data_loader
from helper import AverageMeter, save_checkpoint, accuracy, adjust_learning_rate

def main():
    evaluate = True
    # create model
    model = resnet50()

    # use cuda
    model.cuda()
    # model = torch.nn.parallel.DistributedDataParallel(model)

    # define loss and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = optim.SGD(model.parameters(), lr=0.05,
                          momentum=0.9,
                          weight_decay=0.0005)

    if evaluate:
        validate(model, criterion)
        return 0

    # for epoch in range(args.start_epoch, args.epochs):
    #     adjust_learning_rate(optimizer, epoch, args.lr)

    #     # train for one epoch
    #     train(train_loader, model, criterion, optimizer, epoch, args.print_freq)

    #     # evaluate on validation set
    #     prec1, prec5 = validate(val_loader, model, criterion, args.print_freq)

    #     # remember the best prec@1 and save checkpoint
    #     is_best = prec1 > best_prec1
    #     best_prec1 = max(prec1, best_prec1)

    #     save_checkpoint({
    #         'epoch': epoch + 1,
    #         'arch': args.arch,
    #         'state_dict': model.state_dict(),
    #         'best_prec1': best_prec1,
    #         'optimizer': optimizer.state_dict()
    #     }, is_best, args.arch + '.pth')


# def train(train_loader, model, criterion, optimizer, epoch, print_freq):
#     batch_time = AverageMeter()
#     data_time = AverageMeter()
#     losses = AverageMeter()
#     top1 = AverageMeter()
#     top5 = AverageMeter()

#     # switch to train mode
#     model.train()

#     end = time.time()
#     for i, (input, target) in enumerate(traickpoint({
#             'epoch': epoch + 1,
#             'arch': args.arch,
#             'state_dict': model.state_dict(),
#             'best_prec1': best_prec1,
#             'optimizer': optimizer.state_dict()
#         }, is_best, args.arch + '.pth')

#         target = target.cuda()
#         input = input.cuda()

#         # compute output
#         output = model(input)
#         loss = criterion(output, target)

#         # measure accuracy and record loss
#         prec1, prec5 = accuracy(output.data, target, topk=(1, 5))
#         losses.update(loss.item(), input.size(0))
#         top1.update(prec1[0], input.size(0))
#         top5.update(prec1[0], input.size(0))

#         # compute gradient and do SGD step
#         optimizer.zero_grad()
#         loss.backward()
#         optimizer.step()

#         # measure elapsed time
#         batch_time.update(time.time() - end)
#         end = time.time()

#         if i % print_freq == 0:
#             print('Epoch: [{0}][{1}/{2}]\t'
#                   'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
#                   'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
#                   'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
#                   'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
#                   'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'.format(
#                 epoch, i, len(train_loader), batch_time=batch_time,
#                 data_time=data_time, loss=losses, top1=top1, top5=top5))


def validate(model, criterion):
    
    # switch to evaluate mode
    model.eval()

    input = torch.rand(1, 3, 224, 224)
    
    start = time.time()
    for _ in range(1):
        #target = target.cuda()
        input = input.cuda()
        with torch.no_grad():
            # compute output
            output = model(input)
            #loss = criterion(output, target)

            end = time.time()
    
    print("time :", end - start)
    
    return 0


if __name__ == '__main__':
    main()
