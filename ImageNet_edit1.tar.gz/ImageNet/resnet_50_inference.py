import sys
import torch

from models import *

def main():
    batch = sys.argv[1]
    model = resnet50()

    # use cuda
    model.cuda()
    # model = torch.nn.parallel.DistributedDataParallel(model)

    elapsed_time = get_resnet_time(model, int(batch))
    
    file = open("./resnet50_" + batch + 'batch_' + sys.argv[2] + 'gpu', 'a')
    file.write(str(elapsed_time) + '\n')
    file.close()
    
    return 0


def get_resnet_time(model, batch):
    model.eval()

    input = torch.rand(batch, 3, 224, 224)
    input = input.cuda()
    elapsed_time = -1
    
    with torch.no_grad():
        for _  in range(4):
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            

            start.record()
            output = model(input)
            end.record()
            
            torch.cuda.synchronize()
            
            elapsed_time = start.elapsed_time(end)
            
    return elapsed_time


if __name__ == '__main__':
    main()
