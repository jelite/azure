#!/bin/bash

gpu=$1

./run_batch.sh 16 $gpu
./run_batch.sh 32 $gpu
./run_batch.sh 64 $gpu
./run_batch.sh 128 $gpu
./run_batch.sh 256 $gpu

done
