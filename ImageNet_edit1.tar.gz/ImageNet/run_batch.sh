#!/bin/bash

for i in {1..100}; do
	echo "In $2GPU, $1 batch, $i time start"
	python resnet_50_inference.py $1 $2

done
